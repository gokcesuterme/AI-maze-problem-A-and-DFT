# WRITTEN AND CODED BY GOKCESU TERME & MIRAY MURAT
# 2453587 & 2526549
import heapq


class MazeGraph:
    def __init__(self, file_path):
        self.file_path = file_path
        # robots as nodes and their walk spaces as walkable
        self.nodes, self.walkable = self.load_and_parse_maze()
        self.graph = self.construct_graph()

    def load_and_parse_maze(self):
        maze = []
        nodes = {}
        walkable = set()
        with open(self.file_path, 'r') as file:
            for r, line in enumerate(file):
                row = line.strip().split()
                maze.append(row)
                for c, val in enumerate(row):
                    if val != '#':  # If the character is not a wall ('#'), mark it as walkable
                        walkable.add((r, c))
                    if val not in ('.', '#'):  # If the character is not a wall # or road . it's a node
                        nodes[val] = (r, c)  # Store the coordinates of the node in the dictionary
        return nodes, walkable

    def manhattan_distance(self, start, goal):
        # evaluate manhatten distance
        return abs(start[0] - goal[0]) + abs(start[1] - goal[1])

    def a_star_search(self, start, goal):
        #  directions for pathfinding: down left right up
        directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]

        # for priority queue
        open_set = []

        # Push the start node into the open set with init cost 0 and heuristic value
        heapq.heappush(open_set, (0 + self.manhattan_distance(start, goal), 0, start, [start]))
        visited = set()

        while open_set:
            # pop the node with the lowest total cost from the open set
            _, cost, current, path = heapq.heappop(open_set)
            # if the current node has already been visited, skip it
            if current in visited:
                continue
            visited.add(current)

            # if the current node is the goal, return the path and cost
            if current == goal:
                return path, cost

            # Explore other robots
            for direction in directions:
                # calculate coordinates
                neighbor = (current[0] + direction[0], current[1] + direction[1])
                # check if the neigbbor is walkable and not visited
                if neighbor in self.walkable and neighbor not in visited:
                    new_cost = cost + 1
                    new_path = path + [neighbor]
                    heapq.heappush(open_set, (new_cost + self.manhattan_distance(neighbor, goal), new_cost, neighbor, new_path))

        return None, float('inf')

    def construct_graph(self):

        # Initialize an empty graph with nodes as keys
        graph = {node: [] for node in self.nodes.keys()}
        # Find all shortest paths between nodes with a* search
        node_list = sorted(self.nodes.keys())
        for i in range(len(node_list)):
            for j in range(i + 1, len(node_list)):
                node_a, node_b = node_list[i], node_list[j]
                # Use A* search to find shortest path between node_a and node_b
                path, cost = self.a_star_search(self.nodes[node_a], self.nodes[node_b])
                if path:
                    graph[node_a].append((node_b, cost))
                    graph[node_b].append((node_a, cost))
        return graph

    def dfs(self, current, path, visited, start_node):

        # if the cycle is complete return path
        if len(visited) == len(self.nodes) and current == start_node:
            return path

        # check for neighbors
        for neighbor, cost in self.graph.get(current, []):
            # Check if the neighbor marked as visited or or all visited and neighbor is state A
            if neighbor not in visited or (neighbor == start_node and len(visited) == len(self.nodes)):
                visited.add(neighbor)
                result = self.dfs(neighbor, path + [neighbor], visited, start_node)
                # if a cycle is found, return the path
                if result:
                    return result
                visited.remove(neighbor)  # backtrack: remove the neighbor node from visited set
        return None

    def ucs(self, start_node):
        # Priority queue for UCS algorithm
        queue = [(0, [start_node], {start_node})]

        while queue:
            # Pop the path with the lowest cost from the queue
            cost, path, visited = heapq.heappop(queue)

            # If all nodes have been visited and the cycle is complete then return path
            if len(visited) == len(self.nodes) and path[0] == path[-1]:
                return path
            last_node = path[-1]
            # Explore neighbors
            for neighbor, travel_cost in self.graph[last_node]:
                # check if n is visited or not or all of them complete and the n is start state
                if neighbor not in visited or (len(visited) == len(self.nodes) and neighbor == start_node):
                    new_path = path + [neighbor]
                    new_visited = set(visited)
                    new_visited.add(neighbor)
                    # cost calculation to reach the neighbor node
                    new_cost = cost + travel_cost
                    # push the new path into the queue with new cost
                    heapq.heappush(queue, (new_cost, new_path, new_visited))
        return None

    def print_edges(self):

        # print all edges in alphabetic order
        # edges are the shortes path calculates with the algorithm A * search
        printed = set()
        for node in sorted(self.graph.keys()):
            for neighbor, cost in sorted(self.graph[node], key=lambda x: (x[0], x[1])):
                if (node, neighbor) not in printed and (neighbor, node) not in printed:
                    printed.add((node, neighbor))
                    print(f"{node},{neighbor},{cost}")


# Example usage:
def main():
    graph = MazeGraph("graph.txt")
    graph.print_edges()

    start_node = 'A'

    # if there is no A in the maze cannot do ucs and dfs
    if start_node in graph.nodes:

        # first call the DFS algorithm
        result_path_dfs = graph.dfs(start_node, [start_node], {start_node}, start_node)
        if result_path_dfs:
            print("Complete path found with DFS:", " - ".join(result_path_dfs))
        else:
            print("No complete path is possible with DFS.")

        # CALL THE UCS ALGORTIHM
        result_path_ucs = graph.ucs(start_node)
        if result_path_ucs:
            print("Path found with UCS:", " - ".join(result_path_ucs))
        else:
            print("No complete path is possible with UCS.")
    else:
        print("Start node 'A' not found in nodes.")


if __name__ == "__main__":
    main()
